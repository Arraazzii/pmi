-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 08, 2022 at 02:56 PM
-- Server version: 5.7.37-cll-lve
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `betabkol_pmi`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `code` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `districts` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`code`, `address`, `city`, `districts`, `village`, `phoneNumber`, `email`) VALUES
('220317/ADD/0001', 'tes', 'tes', 'tes', 'tes', '08123456789', ''),
('220317/ADD/0002', 'tes', 'tes', 'tes', 'tes', '08123456789', ''),
('220317/ADD/0003', 'tes', 'tes', 'tes', 'tes', '08123456789', ''),
('220317/ADD/0004', 'tes', 'tes', 'tes', 'tes', '08123456789', ''),
('220317/ADD/0005', 'tes', 'tes', 'tes', 'tes', '08123456789', ''),
('220317/ADD/0006', 'Perum Pesona Laguna Block C2 No 17', 'depok', 'cimanggis', 'CILANGKAP', '0895328976755', ''),
('220317/ADD/0007', 'Perum Pesona Laguna Block C2 No 17', 'depok', 'cimanggis', 'CILANGKAP', '0895328976755', ''),
('220318/ADD/0001', 'A', 'A', 'A', 'A', '088546464', ''),
('220318/ADD/0002', 'A', 'A', 'A', 'A', '088546464', '');

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `code` varchar(20) NOT NULL,
  `noContract` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `endDate` date NOT NULL,
  `companyName` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `sector` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `code` varchar(20) NOT NULL,
  `type` enum('Mandiri','P3MI') NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`code`, `type`, `name`, `status`) VALUES
('mandiri/001', 'Mandiri', 'KTP', '1'),
('mandiri/002', 'Mandiri', 'KK', '1'),
('p3mi/001', 'P3MI', 'Akte', '1');

-- --------------------------------------------------------

--
-- Table structure for table `documentpmi`
--

CREATE TABLE `documentpmi` (
  `id` int(11) NOT NULL,
  `pmiCode` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

CREATE TABLE `family` (
  `code` varchar(20) NOT NULL,
  `motherName` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`code`, `motherName`, `address`, `city`, `district`, `village`, `phoneNumber`) VALUES
('220317/FAM/0001', 'orang', 'tes', 'tes', 'tes', 'tes', '08123456789'),
('220317/FAM/0002', 'orang', 'tes', 'tes', 'tes', 'tes', '08123456789'),
('220317/FAM/0003', 'orang', 'tes', 'tes', 'tes', 'tes', '08123456789'),
('220317/FAM/0004', 'orang', 'tes', 'tes', 'tes', 'tes', '08123456789'),
('220317/FAM/0005', 'orang', 'tes', 'tes', 'tes', 'tes', '08123456789'),
('220317/FAM/0006', 'tes', 'testes', 'tes', 'te', 'tes', '08123456789'),
('220317/FAM/0007', 'tes', 'testes', 'tes', 'te', 'tes', '08123456789'),
('220318/FAM/0001', 'T', 'N', 'G', 'G', 'H', '0087976766'),
('220318/FAM/0002', 'T', 'N', 'G', 'G', 'H', '0087976766');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `code` int(11) NOT NULL,
  `legend` text NOT NULL,
  `ID` text NOT NULL,
  `EN` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logactivity`
--

CREATE TABLE `logactivity` (
  `id` int(11) NOT NULL,
  `userCode` varchar(20) NOT NULL,
  `activity` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logactivity`
--

INSERT INTO `logactivity` (`id`, `userCode`, `activity`, `created`) VALUES
(1, 'USR1', 'Register User with Usercode : USR1', '2021-03-12 15:22:02');

-- --------------------------------------------------------

--
-- Table structure for table `loglogin`
--

CREATE TABLE `loglogin` (
  `id` int(11) NOT NULL,
  `provider` enum('Manual','Google','Facebook') NOT NULL,
  `platform` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `sistem_operasi` varchar(50) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `continent` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `timezone` varchar(100) DEFAULT NULL,
  `longitude` varchar(20) DEFAULT NULL,
  `latitude` varchar(20) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userCode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loglogin`
--

INSERT INTO `loglogin` (`id`, `provider`, `platform`, `ip`, `sistem_operasi`, `country`, `continent`, `city`, `region`, `timezone`, `longitude`, `latitude`, `created`, `userCode`) VALUES
(1, 'Manual', 'Opera 65.0.3467.69', '192.168.1.11', 'Linux', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-09 16:39:02', 'SUPERADMIN'),
(2, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 13:55:54', 'SUPERADMIN'),
(3, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 13:58:57', 'SUPERADMIN'),
(4, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 14:04:08', 'SUPERADMIN'),
(5, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 16:28:40', 'SUPERADMIN'),
(6, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 16:29:30', 'SUPERADMIN'),
(7, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 16:30:50', 'SUPERADMIN'),
(8, 'Manual', 'Chrome 78.0.3904.108', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-15 16:48:05', 'SUPERADMIN'),
(9, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 16:48:38', 'SUPERADMIN'),
(10, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:01:32', 'SUPERADMIN'),
(11, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:02:08', 'SUPERADMIN'),
(12, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:08:45', 'SUPERADMIN'),
(13, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:09:35', 'SUPERADMIN'),
(14, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:10:58', 'SUPERADMIN'),
(15, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:11:26', 'SUPERADMIN'),
(16, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:11:27', 'SUPERADMIN'),
(17, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:11:32', 'SUPERADMIN'),
(18, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:11:34', 'SUPERADMIN'),
(19, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:13:39', 'SUPERADMIN'),
(20, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:14:12', 'SUPERADMIN'),
(21, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-25 17:14:32', 'SUPERADMIN'),
(22, 'Manual', 'Chrome 87.0.4280.66', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 17:26:45', 'SUPERADMIN'),
(23, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 17:40:38', 'SUPERADMIN'),
(24, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 17:47:08', 'SUPERADMIN'),
(25, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 17:48:07', 'SUPERADMIN'),
(26, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 17:50:03', 'SUPERADMIN'),
(27, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:05:10', 'SUPERADMIN'),
(28, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:07:06', 'SUPERADMIN'),
(29, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:51:20', 'SUPERADMIN'),
(30, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:52:43', 'SUPERADMIN'),
(31, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:53:59', 'SUPERADMIN'),
(32, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:55:20', 'SUPERADMIN'),
(33, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:58:07', 'SUPERADMIN'),
(34, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-11-26 18:58:58', 'SUPERADMIN'),
(35, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 17:59:07', 'SUPERADMIN'),
(36, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:00:23', 'SUPERADMIN'),
(37, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:13:47', 'SUPERADMIN'),
(38, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:14:19', 'SUPERADMIN'),
(39, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:15:21', 'SUPERADMIN'),
(40, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:16:07', 'SUPERADMIN'),
(41, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:21:37', 'SUPERADMIN'),
(42, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:22:22', 'SUPERADMIN'),
(43, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:23:01', 'SUPERADMIN'),
(44, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:23:51', 'SUPERADMIN'),
(45, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:24:44', 'SUPERADMIN'),
(46, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:27:49', 'SUPERADMIN'),
(47, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:28:47', 'SUPERADMIN'),
(48, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:29:34', 'SUPERADMIN'),
(49, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:30:46', 'SUPERADMIN'),
(50, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:32:48', 'SUPERADMIN'),
(51, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:56:01', 'SUPERADMIN'),
(52, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 18:56:33', 'SUPERADMIN'),
(53, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:08:26', 'SUPERADMIN'),
(54, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:13:36', 'SUPERADMIN'),
(55, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:14:15', 'SUPERADMIN'),
(56, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:15:36', 'SUPERADMIN'),
(57, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:19:40', 'SUPERADMIN'),
(58, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:20:18', 'SUPERADMIN'),
(59, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:22:59', 'SUPERADMIN'),
(60, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:23:39', 'SUPERADMIN'),
(61, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:24:00', 'SUPERADMIN'),
(62, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:24:20', 'SUPERADMIN'),
(63, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-01 19:24:49', 'SUPERADMIN'),
(64, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 20:07:21', 'SUPERADMIN'),
(65, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 20:09:18', 'SUPERADMIN'),
(66, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:21:50', 'SUPERADMIN'),
(67, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:27:52', 'SUPERADMIN'),
(68, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:28:10', 'SUPERADMIN'),
(69, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:29:37', 'SUPERADMIN'),
(70, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:30:47', 'SUPERADMIN'),
(71, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:31:29', 'SUPERADMIN'),
(72, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:32:06', 'SUPERADMIN'),
(73, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:44:39', 'SUPERADMIN'),
(74, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:46:50', 'SUPERADMIN'),
(75, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-05 21:49:23', 'SUPERADMIN'),
(76, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-06 09:14:40', 'SUPERADMIN'),
(77, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-06 13:26:28', 'SUPERADMIN'),
(78, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-06 13:27:28', 'SUPERADMIN'),
(79, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-13 17:32:09', 'SUPERADMIN'),
(80, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 13:20:46', 'SUPERADMIN'),
(81, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 13:20:46', 'SUPERADMIN'),
(82, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:02:53', 'SUPERADMIN'),
(83, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:03:25', 'SUPERADMIN'),
(84, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:03:51', 'SUPERADMIN'),
(85, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:04:48', 'SUPERADMIN'),
(86, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:12:27', 'SUPERADMIN'),
(87, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:14:13', 'SUPERADMIN'),
(88, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:17:19', 'SUPERADMIN'),
(89, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:19:26', 'SUPERADMIN'),
(90, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:24:19', 'SUPERADMIN'),
(91, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:24:56', 'SUPERADMIN'),
(92, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:26:13', 'SUPERADMIN'),
(93, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:27:36', 'SUPERADMIN'),
(94, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:29:21', 'SUPERADMIN'),
(95, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:29:47', 'SUPERADMIN'),
(96, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:32:15', 'SUPERADMIN'),
(97, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:33:49', 'SUPERADMIN'),
(98, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:39:18', 'SUPERADMIN'),
(99, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:39:59', 'SUPERADMIN'),
(100, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:40:47', 'SUPERADMIN'),
(101, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:41:37', 'SUPERADMIN'),
(102, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:42:36', 'SUPERADMIN'),
(103, 'Manual', 'Safari 604.1', '::1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-25 15:44:21', 'SUPERADMIN'),
(104, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 15:56:13', 'SUPERADMIN'),
(105, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:15:24', 'SUPERADMIN'),
(106, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:17:18', 'SUPERADMIN'),
(107, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:27:39', 'SUPERADMIN'),
(108, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:35:04', 'SUPERADMIN'),
(109, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:37:13', 'SUPERADMIN'),
(110, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:41:21', 'SUPERADMIN'),
(111, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 16:51:14', 'SUPERADMIN'),
(112, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 18:39:42', 'SUPERADMIN'),
(113, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 20:34:24', 'SUPERADMIN'),
(114, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-26 20:34:25', 'SUPERADMIN'),
(115, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 12:54:35', 'SUPERADMIN'),
(116, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 12:55:22', 'SUPERADMIN'),
(117, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 12:59:30', 'SUPERADMIN'),
(118, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:09:32', 'SUPERADMIN'),
(119, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:11:39', 'SUPERADMIN'),
(120, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:12:29', 'SUPERADMIN'),
(121, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:13:31', 'SUPERADMIN'),
(122, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:28:54', 'SUPERADMIN'),
(123, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:29:10', 'SUPERADMIN'),
(124, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:29:44', 'SUPERADMIN'),
(125, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:31:45', 'SUPERADMIN'),
(126, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:32:35', 'SUPERADMIN'),
(127, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:33:33', 'SUPERADMIN'),
(128, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:34:49', 'SUPERADMIN'),
(129, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:35:21', 'SUPERADMIN'),
(130, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:40:42', 'SUPERADMIN'),
(131, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:40:50', 'SUPERADMIN'),
(132, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:41:14', 'SUPERADMIN'),
(133, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:42:05', 'SUPERADMIN'),
(134, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:42:51', 'SUPERADMIN'),
(135, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:43:17', 'SUPERADMIN'),
(136, 'Manual', 'Chrome 87.0.4280.88', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:43:28', 'SUPERADMIN'),
(137, 'Manual', 'Chrome 86.0.4240.198', '::1', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-27 13:46:34', 'SUPERADMIN'),
(138, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-28 15:30:40', 'SUPERADMIN'),
(139, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 09:00:57', 'SUPERADMIN'),
(140, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 15:42:41', 'SUPERADMIN'),
(141, 'Manual', 'Safari 604.1', '180.242.187.57', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 16:05:02', 'SUPERADMIN'),
(142, 'Manual', 'Safari 604.1', '180.242.187.57', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 16:16:38', 'SUPERADMIN'),
(143, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 19:29:07', 'SUPERADMIN'),
(144, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 20:08:46', 'SUPERADMIN'),
(145, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 20:09:46', 'SUPERADMIN'),
(146, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 20:12:07', 'SUPERADMIN'),
(147, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 20:16:45', 'SUPERADMIN'),
(148, 'Manual', 'Chrome 87.0.4280.88', '180.242.187.57', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-12-29 20:20:40', 'SUPERADMIN'),
(149, 'Manual', 'Chrome 87.0.4280.88', '36.77.202.85', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-07 11:48:54', 'SUPERADMIN'),
(150, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:27:23', 'SUPERADMIN'),
(151, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:27:49', 'SUPERADMIN'),
(152, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:43:55', 'SUPERADMIN'),
(153, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:45:26', 'SUPERADMIN'),
(154, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:48:34', 'SUPERADMIN'),
(155, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:52:30', 'SUPERADMIN'),
(156, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 16:54:32', 'SUPERADMIN'),
(157, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:02:46', 'SUPERADMIN'),
(158, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:05:26', 'SUPERADMIN'),
(159, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:18:38', 'SUPERADMIN'),
(160, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:37:01', 'SUPERADMIN'),
(161, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:38:38', 'SUPERADMIN'),
(162, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:42:02', 'SUPERADMIN'),
(163, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:42:49', 'SUPERADMIN'),
(164, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:45:06', 'SUPERADMIN'),
(165, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:47:29', 'SUPERADMIN'),
(166, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:48:05', 'SUPERADMIN'),
(167, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:50:03', 'SUPERADMIN'),
(168, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:52:16', 'SUPERADMIN'),
(169, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 17:57:49', 'SUPERADMIN'),
(170, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:01:41', 'SUPERADMIN'),
(171, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:06:27', 'SUPERADMIN'),
(172, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:08:45', 'SUPERADMIN'),
(173, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:08:45', 'SUPERADMIN'),
(174, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:10:51', 'SUPERADMIN'),
(175, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-12 18:10:51', 'SUPERADMIN'),
(176, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 14:17:53', 'SUPERADMIN'),
(177, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 14:18:13', 'SUPERADMIN'),
(178, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 14:18:40', 'SUPERADMIN'),
(179, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:25:49', 'SUPERADMIN'),
(180, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:34:30', 'SUPERADMIN'),
(181, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:35:58', 'SUPERADMIN'),
(182, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:36:53', 'SUPERADMIN'),
(183, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:40:38', 'SUPERADMIN'),
(184, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:40:56', 'SUPERADMIN'),
(185, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:42:06', 'SUPERADMIN'),
(186, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:43:58', 'SUPERADMIN'),
(187, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:44:41', 'SUPERADMIN'),
(188, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 15:51:12', 'SUPERADMIN'),
(189, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-13 16:01:33', 'SUPERADMIN'),
(190, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 12:49:40', 'SUPERADMIN'),
(191, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 13:06:50', 'SUPERADMIN'),
(192, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:06:08', 'SUPERADMIN'),
(193, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:10:03', 'SUPERADMIN'),
(194, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:10:44', 'SUPERADMIN'),
(195, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:12:07', 'SUPERADMIN'),
(196, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:14:33', 'SUPERADMIN'),
(197, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:35:25', 'SUPERADMIN'),
(198, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:35:59', 'SUPERADMIN'),
(199, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:36:41', 'SUPERADMIN'),
(200, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:37:26', 'SUPERADMIN'),
(201, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:38:17', 'SUPERADMIN'),
(202, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 16:39:00', 'SUPERADMIN'),
(203, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:35:16', 'SUPERADMIN'),
(204, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:36:52', 'SUPERADMIN'),
(205, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:37:55', 'SUPERADMIN'),
(206, 'Manual', 'Chrome 87.0.4280.141', '180.244.233.85', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:51:33', 'SUPERADMIN'),
(207, 'Manual', 'Chrome 87.0.4280.141', '180.244.233.85', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:52:27', 'SUPERADMIN'),
(208, 'Manual', 'Chrome 87.0.4280.141', '180.244.233.85', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 17:52:31', 'SUPERADMIN'),
(209, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 18:24:02', 'SUPERADMIN'),
(210, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 18:24:05', 'SUPERADMIN'),
(211, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 18:24:14', 'SUPERADMIN'),
(212, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 18:24:31', 'SUPERADMIN'),
(213, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:28:53', 'SUPERADMIN'),
(214, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:29:52', 'SUPERADMIN'),
(215, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:29:54', 'SUPERADMIN'),
(216, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:30:01', 'SUPERADMIN'),
(217, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:30:52', 'SUPERADMIN'),
(218, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 19:38:47', 'SUPERADMIN'),
(219, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-15 22:38:23', 'SUPERADMIN'),
(220, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-16 18:13:02', 'SUPERADMIN'),
(221, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-16 18:13:47', 'SUPERADMIN'),
(222, 'Manual', 'Chrome 87.0.4280.141', '125.160.233.107', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-16 18:21:40', 'SUPERADMIN'),
(223, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:40', 'SUPERADMIN'),
(224, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:51', 'SUPERADMIN'),
(225, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:57', 'SUPERADMIN'),
(226, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:57', 'SUPERADMIN'),
(227, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:57', 'SUPERADMIN'),
(228, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:58', 'SUPERADMIN'),
(229, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:58', 'SUPERADMIN'),
(230, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:59', 'SUPERADMIN'),
(231, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:06:59', 'SUPERADMIN'),
(232, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:00', 'SUPERADMIN'),
(233, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:00', 'SUPERADMIN'),
(234, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:01', 'SUPERADMIN'),
(235, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:01', 'SUPERADMIN'),
(236, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:02', 'SUPERADMIN'),
(237, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:02', 'SUPERADMIN'),
(238, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:02', 'SUPERADMIN'),
(239, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:03', 'SUPERADMIN'),
(240, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:03', 'SUPERADMIN'),
(241, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:07:04', 'SUPERADMIN'),
(242, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:08:58', 'SUPERADMIN'),
(243, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:35:17', 'SUPERADMIN'),
(244, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:36:10', 'SUPERADMIN'),
(245, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 05:43:31', 'SUPERADMIN'),
(246, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:19:49', 'SUPERADMIN'),
(247, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:20:05', 'SUPERADMIN'),
(248, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:35:15', 'SUPERADMIN'),
(249, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:36:51', 'SUPERADMIN'),
(250, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:43:03', 'SUPERADMIN'),
(251, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:43:21', 'SUPERADMIN'),
(252, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:47:28', 'SUPERADMIN'),
(253, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:48:42', 'SUPERADMIN'),
(254, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:58:22', 'SUPERADMIN'),
(255, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:59:01', 'SUPERADMIN'),
(256, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 07:59:55', 'SUPERADMIN'),
(257, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:00:26', 'SUPERADMIN'),
(258, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:01:49', 'SUPERADMIN'),
(259, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:06:53', 'SUPERADMIN'),
(260, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:07:38', 'SUPERADMIN'),
(261, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:08:16', 'SUPERADMIN'),
(262, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:09:46', 'SUPERADMIN'),
(263, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:10:26', 'SUPERADMIN'),
(264, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:10:51', 'SUPERADMIN'),
(265, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:11:40', 'SUPERADMIN'),
(266, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:13:13', 'SUPERADMIN'),
(267, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:13:56', 'SUPERADMIN'),
(268, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:15:25', 'SUPERADMIN'),
(269, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:16:19', 'SUPERADMIN'),
(270, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:17:24', 'SUPERADMIN'),
(271, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:19:13', 'SUPERADMIN'),
(272, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:26:35', 'SUPERADMIN'),
(273, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:36:47', 'SUPERADMIN'),
(274, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:38:34', 'SUPERADMIN'),
(275, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:43:26', 'SUPERADMIN'),
(276, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:45:38', 'SUPERADMIN'),
(277, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:47:29', 'SUPERADMIN'),
(278, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:48:31', 'SUPERADMIN'),
(279, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:53:09', 'SUPERADMIN'),
(280, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 08:53:51', 'SUPERADMIN'),
(281, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 11:25:33', 'SUPERADMIN'),
(282, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 11:26:08', 'SUPERADMIN'),
(283, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 11:35:01', 'SUPERADMIN'),
(284, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 11:37:07', 'SUPERADMIN'),
(285, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 11:41:12', 'SUPERADMIN'),
(286, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 12:14:33', 'SUPERADMIN'),
(287, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 12:28:34', 'SUPERADMIN'),
(288, 'Manual', 'Chrome 87.0.4280.141', '125.161.155.184', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 12:28:50', 'SUPERADMIN'),
(289, 'Manual', 'Chrome 87.0.4280.141', '114.124.215.233', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 12:31:48', 'SUPERADMIN'),
(290, 'Manual', 'Chrome 87.0.4280.141', '180.252.86.47', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-17 16:54:24', 'SUPERADMIN'),
(291, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-18 15:04:37', 'SUPERADMIN'),
(292, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-18 15:11:47', 'SUPERADMIN'),
(293, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-18 15:13:36', 'SUPERADMIN'),
(294, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-19 10:41:48', 'SUPERADMIN'),
(295, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-19 10:42:51', 'SUPERADMIN'),
(296, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-19 18:40:36', 'SUPERADMIN'),
(297, 'Manual', 'Chrome 87.0.4280.141', '116.206.8.34', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-19 18:42:53', 'SUPERADMIN'),
(298, 'Manual', 'Chrome 87.0.4280.141', '114.124.196.54', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 11:01:09', 'SUPERADMIN'),
(299, 'Manual', 'Chrome 87.0.4280.141', '114.124.196.54', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 11:01:09', 'SUPERADMIN'),
(300, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 15:48:58', 'SUPERADMIN'),
(301, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 18:40:30', 'SUPERADMIN'),
(302, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:11:37', 'SUPERADMIN'),
(303, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:15:35', 'SUPERADMIN'),
(304, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:15:56', 'SUPERADMIN'),
(305, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:16:32', 'SUPERADMIN'),
(306, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:26:15', 'SUPERADMIN'),
(307, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-20 20:26:52', 'SUPERADMIN'),
(308, 'Manual', 'Chrome 87.0.4280.141', '125.160.226.77', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 09:25:36', 'SUPERADMIN'),
(309, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 12:39:57', 'SUPERADMIN'),
(310, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 12:41:37', 'SUPERADMIN'),
(311, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 12:59:31', 'SUPERADMIN'),
(312, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 13:03:14', 'SUPERADMIN'),
(313, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 13:11:25', 'SUPERADMIN'),
(314, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 13:12:09', 'SUPERADMIN'),
(315, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 13:13:36', 'SUPERADMIN'),
(316, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 13:14:52', 'SUPERADMIN'),
(317, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 17:10:01', 'SUPERADMIN'),
(318, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 17:29:55', 'SUPERADMIN'),
(319, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-21 17:38:48', 'SUPERADMIN'),
(320, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-22 16:07:54', 'SUPERADMIN'),
(321, 'Manual', 'Safari 604.1', '125.160.249.62', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-22 16:28:53', 'SUPERADMIN'),
(322, 'Manual', 'Chrome 80.0.3987.99', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-22 16:41:20', 'SUPERADMIN'),
(323, 'Manual', 'Chrome 88.0.4324.93', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-22 16:41:50', 'SUPERADMIN'),
(324, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 13:45:40', 'SUPERADMIN'),
(325, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 13:46:29', 'SUPERADMIN'),
(326, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:09:57', 'SUPERADMIN'),
(327, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:17:03', 'SUPERADMIN'),
(328, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:19:12', 'SUPERADMIN'),
(329, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:27:49', 'SUPERADMIN'),
(330, 'Manual', 'Safari 604.1', '125.160.249.62', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:28:17', 'SUPERADMIN'),
(331, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:33:07', 'SUPERADMIN'),
(332, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:33:07', 'SUPERADMIN'),
(333, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:34:27', 'SUPERADMIN'),
(334, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:35:55', 'SUPERADMIN'),
(335, 'Manual', 'Safari 604.1', '125.160.249.62', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:37:35', 'SUPERADMIN'),
(336, 'Manual', 'Safari 604.1', '125.160.249.62', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:39:16', 'SUPERADMIN'),
(337, 'Manual', 'Safari 604.1', '125.160.249.62', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:43:38', 'SUPERADMIN'),
(338, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 15:48:52', 'SUPERADMIN'),
(339, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:11:55', 'SUPERADMIN'),
(340, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:19:12', 'SUPERADMIN'),
(341, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:21:56', 'SUPERADMIN'),
(342, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:22:14', 'SUPERADMIN'),
(343, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:37:18', 'SUPERADMIN'),
(344, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 16:41:43', 'SUPERADMIN'),
(345, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 17:08:28', 'SUPERADMIN'),
(346, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 18:11:27', 'SUPERADMIN'),
(347, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 18:12:27', 'SUPERADMIN'),
(348, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 18:14:41', 'SUPERADMIN'),
(349, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:46:35', 'SUPERADMIN'),
(350, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:53:03', 'SUPERADMIN'),
(351, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:54:14', 'SUPERADMIN'),
(352, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:57:08', 'SUPERADMIN'),
(353, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:58:51', 'SUPERADMIN'),
(354, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 20:59:27', 'SUPERADMIN');
INSERT INTO `loglogin` (`id`, `provider`, `platform`, `ip`, `sistem_operasi`, `country`, `continent`, `city`, `region`, `timezone`, `longitude`, `latitude`, `created`, `userCode`) VALUES
(355, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:02:03', 'SUPERADMIN'),
(356, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:03:35', 'SUPERADMIN'),
(357, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:04:43', 'SUPERADMIN'),
(358, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:05:56', 'SUPERADMIN'),
(359, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:12:53', 'SUPERADMIN'),
(360, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:19:17', 'SUPERADMIN'),
(361, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:20:16', 'SUPERADMIN'),
(362, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:26:46', 'SUPERADMIN'),
(363, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:31:23', 'SUPERADMIN'),
(364, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 21:35:47', 'SUPERADMIN'),
(365, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-23 22:37:31', 'SUPERADMIN'),
(366, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 08:07:52', 'SUPERADMIN'),
(367, 'Manual', 'Chrome 88.0.4324.93', '114.124.130.53', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 12:57:57', 'SUPERADMIN'),
(368, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 13:15:15', 'SUPERADMIN'),
(369, 'Manual', 'Chrome 87.0.4280.141', '116.206.8.36', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 13:34:49', 'SUPERADMIN'),
(370, 'Manual', 'Chrome 87.0.4280.141', '116.206.8.36', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 13:49:51', 'SUPERADMIN'),
(371, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:07:31', 'SUPERADMIN'),
(372, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:07:34', 'SUPERADMIN'),
(373, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:09:09', 'SUPERADMIN'),
(374, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:11:19', 'SUPERADMIN'),
(375, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:14:25', 'SUPERADMIN'),
(376, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:14:47', 'SUPERADMIN'),
(377, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:17:28', 'SUPERADMIN'),
(378, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:18:34', 'SUPERADMIN'),
(379, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:18:42', 'SUPERADMIN'),
(380, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:21:14', 'SUPERADMIN'),
(381, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:21:45', 'SUPERADMIN'),
(382, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:21:49', 'SUPERADMIN'),
(383, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:26:09', 'SUPERADMIN'),
(384, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 14:42:23', 'SUPERADMIN'),
(385, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 16:25:09', 'SUPERADMIN'),
(386, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 17:09:27', 'SUPERADMIN'),
(387, 'Manual', 'Chrome 87.0.4280.141', '125.160.249.62', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 17:57:56', 'SUPERADMIN'),
(388, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-24 19:08:42', 'SUPERADMIN'),
(389, 'Manual', 'Chrome 87.0.4280.141', '116.206.13.81', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 06:16:55', 'SUPERADMIN'),
(390, 'Manual', 'Chrome 87.0.4280.141', '116.206.13.81', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 06:17:59', 'SUPERADMIN'),
(391, 'Manual', 'Safari 604.1', '125.160.234.156', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 13:35:48', 'SUPERADMIN'),
(392, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 15:54:52', 'SUPERADMIN'),
(393, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 17:10:00', 'SUPERADMIN'),
(394, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 17:14:19', 'SUPERADMIN'),
(395, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 17:18:48', 'SUPERADMIN'),
(396, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 19:00:12', 'SUPERADMIN'),
(397, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 19:00:32', 'SUPERADMIN'),
(398, 'Manual', 'Chrome 87.0.4280.141', '110.138.121.33', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-25 19:17:01', 'SUPERADMIN'),
(399, 'Manual', 'Chrome 87.0.4280.141', '223.255.230.7', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 07:22:35', 'SUPERADMIN'),
(400, 'Manual', 'Safari 604.1', '125.160.236.75', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 08:16:26', 'SUPERADMIN'),
(401, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 13:41:33', 'SUPERADMIN'),
(402, 'Manual', 'Safari 602.1', '125.160.231.167', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 14:02:22', 'SUPERADMIN'),
(403, 'Manual', 'Chrome 83.0.4103.106', '182.2.133.146', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 15:34:26', 'SUPERADMIN'),
(404, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 15:56:26', 'SUPERADMIN'),
(405, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 16:06:03', 'SUPERADMIN'),
(406, 'Manual', 'Safari 604.1', '125.160.231.167', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 16:20:56', 'SUPERADMIN'),
(407, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 16:22:42', 'SUPERADMIN'),
(408, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 16:26:34', 'SUPERADMIN'),
(409, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-26 17:11:15', 'SUPERADMIN'),
(410, 'Manual', 'Chrome 87.0.4280.141', '182.253.155.108', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-27 05:00:02', 'SUPERADMIN'),
(411, 'Manual', 'Chrome 87.0.4280.141', '125.160.231.167', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-27 15:05:56', 'SUPERADMIN'),
(412, 'Manual', 'Safari 604.1', '180.244.234.20', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-28 14:19:42', 'SUPERADMIN'),
(413, 'Manual', 'Safari 604.1', '125.160.236.49', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-28 14:32:10', 'SUPERADMIN'),
(414, 'Manual', 'Chrome 88.0.4324.104', '36.71.218.212', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-28 14:33:21', 'SUPERADMIN'),
(415, 'Manual', 'Chrome 88.0.4324.104', '36.71.218.212', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-28 18:10:54', 'SUPERADMIN'),
(416, 'Manual', 'Chrome 88.0.4324.104', '36.71.218.212', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-28 18:13:40', 'SUPERADMIN'),
(417, 'Manual', 'Chrome 88.0.4324.104', '139.255.62.242', 'Windows 7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 02:28:14', 'SUPERADMIN'),
(418, 'Manual', 'Safari 604.1', '139.255.62.242', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 02:52:03', 'SUPERADMIN'),
(419, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:21:09', 'SUPERADMIN'),
(420, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:26:52', 'SUPERADMIN'),
(421, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:33:41', 'SUPERADMIN'),
(422, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:35:52', 'SUPERADMIN'),
(423, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:36:59', 'SUPERADMIN'),
(424, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Windows 7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 14:39:36', 'SUPERADMIN'),
(425, 'Manual', 'Safari 602.1', '110.138.91.191', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 15:19:47', 'SUPERADMIN'),
(426, 'Manual', 'Safari 604.1', '110.138.91.191', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 15:44:02', 'SUPERADMIN'),
(427, 'Manual', 'Safari 604.1', '110.138.91.191', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 15:47:12', 'SUPERADMIN'),
(428, 'Manual', 'Safari 604.1', '110.138.91.191', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 15:52:58', 'SUPERADMIN'),
(429, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-29 16:53:55', 'SUPERADMIN'),
(430, 'Manual', 'Chrome 88.0.4324.104', '180.244.234.20', 'Windows 7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 16:10:42', 'SUPERADMIN'),
(431, 'Manual', 'Chrome 88.0.4324.104', '180.244.234.20', 'Windows 7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 16:28:32', 'SUPERADMIN'),
(432, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:18:17', 'SUPERADMIN'),
(433, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:43:50', 'SUPERADMIN'),
(434, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:44:14', 'SUPERADMIN'),
(435, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:46:51', 'SUPERADMIN'),
(436, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:50:41', 'SUPERADMIN'),
(437, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:51:41', 'SUPERADMIN'),
(438, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:52:59', 'SUPERADMIN'),
(439, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:53:46', 'SUPERADMIN'),
(440, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 17:55:33', 'SUPERADMIN'),
(441, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 19:02:17', 'SUPERADMIN'),
(442, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 19:03:06', 'SUPERADMIN'),
(443, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 19:14:54', 'SUPERADMIN'),
(444, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 19:37:21', 'SUPERADMIN'),
(445, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 21:09:01', 'SUPERADMIN'),
(446, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 21:10:45', 'SUPERADMIN'),
(447, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 21:12:37', 'SUPERADMIN'),
(448, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 21:23:33', 'SUPERADMIN'),
(449, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 21:28:46', 'SUPERADMIN'),
(450, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 22:19:05', 'SUPERADMIN'),
(451, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 22:21:30', 'SUPERADMIN'),
(452, 'Manual', 'Chrome 88.0.4324.93', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 22:23:05', 'SUPERADMIN'),
(453, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 23:27:02', 'SUPERADMIN'),
(454, 'Manual', 'Chrome 88.0.4324.104', '110.138.91.191', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-30 23:28:48', 'SUPERADMIN'),
(455, 'Manual', 'Chrome 88.0.4324.146', '125.160.231.110', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-07 12:58:27', 'SUPERADMIN'),
(456, 'Manual', 'Chrome 88.0.4324.146', '125.160.231.110', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-07 12:58:53', 'SUPERADMIN'),
(457, 'Manual', 'Safari 604.1', '182.16.166.242', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-16 03:01:33', 'SUPERADMIN'),
(458, 'Manual', 'Chrome 88.0.4324.182', '110.138.88.114', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-20 11:55:09', 'SUPERADMIN'),
(459, 'Manual', 'Chrome 88.0.4324.182', '110.138.88.114', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-20 14:16:22', 'SUPERADMIN'),
(460, 'Manual', 'Chrome 88.0.4324.190', '36.83.199.190', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-27 16:04:39', 'SUPERADMIN'),
(461, 'Manual', 'Chrome 88.0.4324.190', '36.83.199.190', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-27 16:13:59', 'SUPERADMIN'),
(462, 'Manual', 'Safari 604.1', '180.244.234.1', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-03 12:25:47', 'SUPERADMIN'),
(463, 'Manual', 'Chrome 88.0.4324.190', '125.166.214.205', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-08 14:38:21', 'SUPERADMIN'),
(464, 'Manual', 'Safari 604.1', '125.166.214.205', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-08 14:57:26', 'SUPERADMIN'),
(465, 'Manual', 'Safari 604.1', '125.166.214.205', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-08 15:00:25', 'SUPERADMIN'),
(466, 'Manual', 'Safari 604.1', '182.16.166.242', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-09 03:00:47', 'SUPERADMIN'),
(467, 'Manual', 'Chrome 88.0.4324.190', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-11 16:08:10', 'SUPERADMIN'),
(468, 'Manual', 'Chrome 88.0.4324.190', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 21:54:47', 'SUPERADMIN'),
(469, 'Manual', 'Chrome 88.0.4324.190', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 22:05:06', 'SUPERADMIN'),
(470, 'Manual', 'Chrome 89.0.4389.86', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 22:12:53', 'SUPERADMIN'),
(471, 'Manual', 'Chrome 89.0.4389.86', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 22:19:14', 'SUPERADMIN'),
(472, 'Manual', 'Chrome 88.0.4324.190', '36.71.214.240', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 22:19:17', 'SUPERADMIN'),
(473, 'Manual', 'Chrome 88.0.4324.181', '110.138.85.53', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-03-12 23:58:43', 'SUPERADMIN'),
(474, 'Manual', 'Safari 604.1', '61.94.100.30', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-11 10:31:48', 'SUPERADMIN'),
(475, 'Manual', 'Safari 604.1', '180.246.148.134', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-28 05:27:41', 'SUPERADMIN'),
(476, 'Manual', 'Chrome 91.0.4472.114', '110.138.95.161', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-06-27 13:19:46', 'SUPERADMIN'),
(477, 'Manual', 'Safari 604.1', '103.214.112.42', 'iOS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-20 09:41:57', 'SUPERADMIN'),
(478, 'Manual', 'Chrome 91.0.4472.120', '110.138.93.58', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-07-20 15:34:39', 'SUPERADMIN'),
(479, 'Manual', 'Chrome 99.0.4844.51', '192.168.69.10', 'Windows 10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-17 06:45:53', 'SUPERADMIN'),
(480, 'Manual', 'Chrome 97.0.4692.98', '120.188.67.127', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-18 04:54:01', 'SUPERADMIN'),
(481, 'Manual', 'Chrome 97.0.4692.98', '120.188.67.127', 'Android', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-18 04:58:21', 'SUPERADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `p3mi`
--

CREATE TABLE `p3mi` (
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `directoreName` varchar(100) NOT NULL,
  `directorContact` varchar(20) NOT NULL,
  `license` varchar(20) NOT NULL,
  `addressCode` varchar(20) NOT NULL,
  `disnaker` date NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pmi`
--

CREATE TABLE `pmi` (
  `code` varchar(20) NOT NULL,
  `type` enum('Mandiri','P3MI') NOT NULL,
  `p3miCode` varchar(20) DEFAULT NULL,
  `disnaker` date NOT NULL,
  `nik` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `formalEducation` varchar(50) NOT NULL,
  `familyCode` varchar(20) NOT NULL,
  `contractCode` varchar(20) NOT NULL,
  `addressCode` varchar(20) NOT NULL,
  `arrive` date DEFAULT NULL,
  `home` date DEFAULT NULL,
  `ajukan` enum('0','1') NOT NULL DEFAULT '0',
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pmi`
--

INSERT INTO `pmi` (`code`, `type`, `p3miCode`, `disnaker`, `nik`, `name`, `religion`, `formalEducation`, `familyCode`, `contractCode`, `addressCode`, `arrive`, `home`, `ajukan`, `status`, `created`) VALUES
('220317/PMI/0001', 'Mandiri', '', '2022-03-17', '3276020905121514', 'tes', 'islam', 'S1', '220317/FAM/0001', '220317/CON/0001', '220317/ADD/0001', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:43:19'),
('220317/PMI/0002', 'Mandiri', '', '2022-03-17', '3276020905121514', 'tes', 'islam', 'S1', '220317/FAM/0002', '220317/CON/0001', '220317/ADD/0002', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:43:23'),
('220317/PMI/0003', 'Mandiri', '', '2022-03-17', '3276020905121514', 'tes', 'islam', 'S1', '220317/FAM/0003', '220317/CON/0001', '220317/ADD/0003', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:43:24'),
('220317/PMI/0004', 'Mandiri', '', '2022-03-17', '3276020905121514', 'tes', 'islam', 'S1', '220317/FAM/0004', '220317/CON/0001', '220317/ADD/0004', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:43:24'),
('220317/PMI/0005', 'Mandiri', '', '2022-03-17', '3276020905121514', 'tes', 'islam', 'S1', '220317/FAM/0005', '220317/CON/0001', '220317/ADD/0005', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:43:25'),
('220317/PMI/0006', 'Mandiri', '', '2022-03-16', '3276020905000004', 'Muhammad \'Umar \'Aziz', 'Islam', 'SMK / MAK', '220317/FAM/0006', '220317/CON/0001', '220317/ADD/0006', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:50:45'),
('220317/PMI/0007', 'Mandiri', '', '2022-03-16', '3276020905000004', 'Muhammad \'Umar \'Aziz', 'Islam', 'SMK / MAK', '220317/FAM/0007', '220317/CON/0001', '220317/ADD/0007', '0000-00-00', '0000-00-00', '1', '0', '2022-03-17 13:50:55'),
('220318/PMI/0001', 'Mandiri', '', '2022-03-19', '123456', 'A', 'A', 'Q', '220318/FAM/0001', '220318/CON/0001', '220318/ADD/0001', '0000-00-00', '0000-00-00', '1', '0', '2022-03-18 11:57:45'),
('220318/PMI/0002', 'Mandiri', '', '2022-03-19', '123456', 'A', 'A', 'Q', '220318/FAM/0002', '220318/CON/0001', '220318/ADD/0002', '0000-00-00', '0000-00-00', '1', '0', '2022-03-18 11:58:37');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `code` varchar(20) NOT NULL,
  `type` enum('Hari Kerja','Sektor Usaha','Jenis Pekerjaan','Negara') NOT NULL,
  `description` varchar(100) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`code`, `type`, `description`, `status`) VALUES
('HK/001', 'Hari Kerja', 'Sabtu', '1'),
('JP/001', 'Jenis Pekerjaan', 'Developer', '1'),
('Negara/001', 'Negara', 'Indonesia', '1'),
('SU/001', 'Sektor Usaha', 'IT', '1');

-- --------------------------------------------------------

--
-- Table structure for table `setup`
--

CREATE TABLE `setup` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setup`
--

INSERT INTO `setup` (`id`, `key`, `value`) VALUES
(1, 'logActivity', 'true'),
(2, 'loginGoogle', 'false'),
(3, 'loginFacebook', 'false'),
(4, 'logLogin', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userCode` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `picture_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profile_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` enum('Admin','User') COLLATE utf8_unicode_ci NOT NULL,
  `currency` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userCode`, `oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `email`, `username`, `password`, `gender`, `locale`, `address`, `phone_number`, `picture_url`, `profile_url`, `level`, `currency`, `created`, `modified`) VALUES
('SUPERADMIN', 'google', '111758044335618659363', 'Muhammad \'Umar', '\'Aziz', 'mumaraziz2014@gmail.com', '', '21232f297a57a5a743894a0e4a801fc3', '', 'en', '', '', 'https://lh3.googleusercontent.com/a-/AOh14GhGKDp7KspU_zawB6AsK4QxyS_FdM0YIcJ57Sj31Q', '', 'Admin', 66, '2020-04-06 13:28:30', '2022-03-17 06:45:38'),
('USR1', '', '', '', '', 'ariariyanto0404@gmail.com', '', '21232f297a57a5a743894a0e4a801fc3', '', '', '', '', '', '', 'User', 0, '2021-03-12 15:22:02', '2022-03-17 06:53:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `documentpmi`
--
ALTER TABLE `documentpmi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `family`
--
ALTER TABLE `family`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `logactivity`
--
ALTER TABLE `logactivity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loglogin`
--
ALTER TABLE `loglogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p3mi`
--
ALTER TABLE `p3mi`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `pmi`
--
ALTER TABLE `pmi`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `setup`
--
ALTER TABLE `setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `documentpmi`
--
ALTER TABLE `documentpmi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `code` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logactivity`
--
ALTER TABLE `logactivity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loglogin`
--
ALTER TABLE `loglogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=482;

--
-- AUTO_INCREMENT for table `setup`
--
ALTER TABLE `setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
